import assert from "node:assert/strict";
import net from "node:net";
import os from "node:os";
import path from "node:path";
import test from "node:test";
import { once } from "node:events";
import { mkdtemp, readFile, rm, writeFile } from "node:fs/promises";
import WebSocket from "ws";
import { createScopedToken, createToken } from "../src/auth.js";
import { parseHostFrame, peerFrame } from "../src/lan-rooms.js";
import { makeHandshake, normalizeBinaryData, parseTarget, validateMinecraftHandshake } from "../src/protocol.js";
import { createRelayServer } from "../src/server.js";

const SECRET = "test-secret-at-least-16-characters";

test("Cloudflare keeps live relay streams off the Durable Object request meter", async () => {
  const worker = await readFile(new URL("../cloudflare/worker.js", import.meta.url), "utf8");
  const config = await readFile(new URL("../cloudflare/wrangler.toml", import.meta.url), "utf8");
  assert.match(worker, /openMinecraftTunnel\(request, target, env, ctx\)/);
  assert.match(worker, /minecraftRuntime: "stateless-worker"/);
  assert.doesNotMatch(worker, /MINECRAFT_TUNNELS\.newUniqueId\(\)/);
  assert.match(worker, /export class MinecraftTunnel/);
  assert.doesNotMatch(config, /name = "MINECRAFT_TUNNELS"\s+class_name = "MinecraftTunnel"/);
  assert.doesNotMatch(config, /\[\[durable_objects\.bindings\]\]/);
  assert.match(worker, /return openLanUpstream\(request, env\)/);
  assert.match(config, /RELAY_LAN_UPSTREAM = "https:\/\/relay\.deev\.is\/"/);
  assert.match(config, /RELAY_MAX_LIFETIME_MS = "0"/);
  assert.match(config, /tag = "v1"\s+new_sqlite_classes = \["LanRoom"\]/);
  assert.match(config, /tag = "v2"\s+new_sqlite_classes = \["MinecraftTunnel"\]/);
});

test("serves the standalone client from the relay origin without caching", async (t) => {
  const directory = await mkdtemp(path.join(os.tmpdir(), "eagler-relay-client-"));
  const clientHtml = path.join(directory, "client.html");
  await writeFile(clientHtml, "<!doctype html><title>relay client</title>");
  t.after(() => rm(directory, { recursive: true, force: true }));

  const relay = createRelayServer({ publicAccess: true, clientHtml });
  relay.listen(0, "127.0.0.1");
  await once(relay, "listening");
  t.after(() => relay.close());
  const origin = `http://127.0.0.1:${relay.address().port}`;

  const client = await fetch(origin + "/");
  assert.equal(client.status, 200);
  assert.equal(client.headers.get("cache-control"), "no-store");
  assert.match(await client.text(), /relay client/);

  await writeFile(clientHtml, "<!doctype html><title>rebuilt relay client</title>");
  const rebuilt = await fetch(origin + "/");
  const rebuiltBody = await rebuilt.text();
  assert.equal(Number(rebuilt.headers.get("content-length")), Buffer.byteLength(rebuiltBody));
  assert.match(rebuiltBody, /rebuilt relay client/);

  const health = await (await fetch(origin + "/health")).json();
  assert.equal(health.client, true);
});

test("normalizes Cloudflare WebSocket binary payload shapes", async () => {
  const expected = Buffer.from([1, 2, 3, 4, 5]);
  assert.deepEqual(Buffer.from(await normalizeBinaryData(expected)), expected);
  assert.deepEqual(Buffer.from(await normalizeBinaryData(new Blob([expected]))), expected);
  assert.equal(await normalizeBinaryData("not binary"), null);
});

test("validates a real Java handshake frame", () => {
  const packet = makeHandshake("localhost", 25565);
  const parsed = validateMinecraftHandshake(packet);
  assert.equal(parsed.status, "valid");
  assert.equal(parsed.host, "localhost");
  assert.equal(parsed.port, 25565);
  assert.equal(validateMinecraftHandshake(packet.slice(0, 3)).status, "more");
  const invalid = packet.slice();
  invalid[1] = 3;
  assert.equal(validateMinecraftHandshake(invalid).status, "invalid");
});

test("defaults hostname-only and bracketed IPv6 targets to Minecraft port 25565", () => {
  assert.deepEqual(parseTarget("play.example.com"), {
    host: "play.example.com",
    port: 25565,
    canonical: "play.example.com:25565"
  });
  assert.deepEqual(parseTarget("[2001:db8::1]"), {
    host: "2001:db8::1",
    port: 25565,
    canonical: "[2001:db8::1]:25565"
  });
  assert.equal(parseTarget("play.example.com:25566").port, 25566);
});

test("rejects a handshake for a different target port", async (t) => {
  const target = net.createServer();
  target.listen(0, "127.0.0.1");
  await once(target, "listening");
  t.after(() => target.close());
  const targetPort = target.address().port;

  const relay = createRelayServer({ secret: SECRET, allowPrivate: true, maxLifetimeMs: 30000 });
  relay.listen(0, "127.0.0.1");
  await once(relay, "listening");
  t.after(() => relay.close());
  const relayPort = relay.address().port;
  const canonical = `127.0.0.1:${targetPort}`;
  const token = createToken(SECRET, canonical);
  const ws = new WebSocket(`ws://127.0.0.1:${relayPort}/minecraft?target=${encodeURIComponent(canonical)}&token=${token}`);
  await once(ws, "open");
  ws.send(makeHandshake("offline.test", targetPort === 65535 ? 65534 : targetPort + 1));
  const [code, reason] = await once(ws, "close");
  assert.equal(code, 1008);
  assert.match(reason.toString(), /target port mismatch/);
});

test("authenticated relay preserves the Minecraft TCP byte stream", async (t) => {
  const received = [];
  const target = net.createServer((socket) => {
    socket.on("data", (data) => {
      received.push(data);
      socket.write(Buffer.from([0x03, 0x02, 0x01]));
    });
  });
  target.listen(0, "127.0.0.1");
  await once(target, "listening");
  t.after(() => target.close());
  const targetPort = target.address().port;

  const relay = createRelayServer({ secret: SECRET, allowPrivate: true, maxLifetimeMs: 30000 });
  relay.listen(0, "127.0.0.1");
  await once(relay, "listening");
  t.after(() => relay.close());
  const relayPort = relay.address().port;
  const canonical = `127.0.0.1:${targetPort}`;
  const token = createToken(SECRET, canonical);
  const ws = new WebSocket(`ws://127.0.0.1:${relayPort}/minecraft?target=${encodeURIComponent(canonical)}&token=${token}`);
  await once(ws, "open");
  t.after(() => ws.close());

  const handshake = makeHandshake("offline.test", targetPort);
  const extra = Buffer.from([0x05, 0x00, 0x03, 0x61, 0x62, 0x63]);
  ws.send(handshake.slice(0, 4));
  ws.send(Buffer.concat([handshake.slice(4), extra]));
  const [reply] = await once(ws, "message");
  assert.deepEqual(Buffer.from(reply), Buffer.from([0x03, 0x02, 0x01]));
  await new Promise((resolve) => setTimeout(resolve, 20));
  assert.deepEqual(Buffer.concat(received), Buffer.concat([handshake, extra]));
});

test("reports a clean target EOF with a useful close reason", async (t) => {
  const target = net.createServer((socket) => {
    socket.once("data", () => socket.end());
  });
  target.listen(0, "127.0.0.1");
  await once(target, "listening");
  t.after(() => target.close());

  const relay = createRelayServer({ publicAccess: true, allowPrivate: true });
  relay.listen(0, "127.0.0.1");
  await once(relay, "listening");
  t.after(() => relay.close());

  const targetPort = target.address().port;
  const ws = new WebSocket(
    `ws://127.0.0.1:${relay.address().port}/minecraft?target=127.0.0.1%3A${targetPort}`
  );
  await once(ws, "open");
  ws.send(makeHandshake("127.0.0.1", targetPort));
  const [code, reason] = await once(ws, "close");
  assert.equal(code, 1000);
  assert.equal(reason.toString(), "target closed");
});

test("rejects missing authentication before opening TCP", async (t) => {
  const relay = createRelayServer({ secret: SECRET, allowPrivate: true });
  relay.listen(0, "127.0.0.1");
  await once(relay, "listening");
  t.after(() => relay.close());
  const port = relay.address().port;
  const ws = new WebSocket(`ws://127.0.0.1:${port}/minecraft?target=127.0.0.1%3A25565`);
  const [error] = await once(ws, "error");
  assert.match(error.message, /401/);
});

test("public relay accepts a tokenless Minecraft connection", async (t) => {
  const target = net.createServer((socket) => {
    socket.once("data", (data) => socket.write(data));
  });
  target.listen(0, "127.0.0.1");
  await once(target, "listening");
  t.after(() => target.close());

  const targetAddress = target.address();
  const relay = createRelayServer({ publicAccess: true, allowPrivate: true });
  relay.listen(0, "127.0.0.1");
  await once(relay, "listening");
  t.after(() => relay.close());

  const relayAddress = relay.address();
  const targetName = `127.0.0.1:${targetAddress.port}`;
  const ws = new WebSocket(
    `ws://127.0.0.1:${relayAddress.port}/minecraft?target=${encodeURIComponent(targetName)}`
  );
  t.after(() => ws.close());
  await once(ws, "open");

  const handshake = makeHandshake("127.0.0.1", targetAddress.port);
  ws.send(handshake);
  const [echo] = await once(ws, "message");
  assert.deepEqual(new Uint8Array(echo), handshake);
});

test("LAN room relays opaque Minecraft bytes in both directions", async (t) => {
  const relay = createRelayServer({
    secret: SECRET,
    allowPrivate: true,
    maxLifetimeMs: 30000,
    maxBytesPerMinute: 1,
    maxLanBytesPerMinute: 1024
  });
  relay.listen(0, "127.0.0.1");
  await once(relay, "listening");
  t.after(() => relay.close());
  const port = relay.address().port;

  const hostToken = createScopedToken(SECRET, "lan-host");
  const host = new WebSocket(`ws://127.0.0.1:${port}/lan/host?token=${encodeURIComponent(hostToken)}`);
  const hostedMessage = once(host, "message");
  await once(host, "open");
  t.after(() => host.close());
  const [hostedRaw] = await hostedMessage;
  const hosted = JSON.parse(hostedRaw.toString());
  assert.equal(hosted.type, "hosted");
  assert.match(hosted.code, /^[A-HJ-NP-Z2-9]{6}$/);

  const peerOpenedMessage = once(host, "message");
  const guest = new WebSocket(`ws://127.0.0.1:${port}/lan/join?code=${hosted.code}`);
  await once(guest, "open");
  t.after(() => guest.close());
  const [openedRaw] = await peerOpenedMessage;
  const opened = JSON.parse(openedRaw.toString());
  assert.equal(opened.type, "peer-open");
  assert.match(opened.peer, /^[0-9a-f]{16}$/);

  const clientBytes = Buffer.from([0x05, 0x00, 0x03, 0x61, 0x62, 0x63]);
  const clientFrameMessage = once(host, "message");
  guest.send(clientBytes);
  const [multiplexed, isBinary] = await clientFrameMessage;
  assert.equal(isBinary, true);
  const fromGuest = parseHostFrame(multiplexed);
  assert.equal(fromGuest.peerId, opened.peer);
  assert.deepEqual(fromGuest.payload, clientBytes);

  const serverBytes = Buffer.from([0x03, 0x02, 0x01]);
  const serverFrameMessage = once(guest, "message");
  host.send(peerFrame(opened.peer, serverBytes));
  const [reply, replyBinary] = await serverFrameMessage;
  assert.equal(replyBinary, true);
  assert.deepEqual(Buffer.from(reply), serverBytes);
});

test("LAN hosting rejects target-scoped and missing tokens", async (t) => {
  const relay = createRelayServer({ secret: SECRET, allowPrivate: true });
  relay.listen(0, "127.0.0.1");
  await once(relay, "listening");
  t.after(() => relay.close());
  const port = relay.address().port;
  const targetToken = createToken(SECRET, "example.com:25565");

  const wrongScope = new WebSocket(
    `ws://127.0.0.1:${port}/lan/host?token=${encodeURIComponent(targetToken)}`
  );
  const [wrongError] = await once(wrongScope, "error");
  assert.match(wrongError.message, /401/);

  const missing = new WebSocket(`ws://127.0.0.1:${port}/lan/host`);
  const [missingError] = await once(missing, "error");
  assert.match(missingError.message, /401/);
});
